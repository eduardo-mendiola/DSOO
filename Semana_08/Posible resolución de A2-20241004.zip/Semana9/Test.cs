﻿using System;
using System.Collections.Generic;

namespace Semana9
{
    internal class Test
    {
        static void Main(string[] args)
        {
            List<Producto> productos = new List<Producto>();
            // Creamos algunos productos de ejemplo y los agregamos a la lista
            productos.Add(new ProductoPerecedero
            {
                Nombre = "Leche",
                Precio = 50.0,
                Tipo = "Perecedero",
                DiasACaducar = 4
            });
            productos.Add(new ProductoPerecedero
            {
                Nombre = "Crema",
                Precio = 450.0,
                Tipo = "Perecedero",
                DiasACaducar = 24
            });
            productos.Add(new ProductoPerecedero
            {
                Nombre = "Queso untable",
                Precio = 550.0,
                Tipo = "Perecedero",
                DiasACaducar = 1
            });
            productos.Add(new ProductoNoPerecedero
            {
                Nombre = "Lentejas",
                Precio = 30.0,
                Tipo = "No Perecedero",
                Categoria = "Legumbre"
            });
            productos.Add(new ProductoNoPerecedero
            {
                Nombre = "Gaseosa",
                Precio = 330.0,
                Tipo = "No Perecedero",
                Categoria = "Bebida"
            });
            productos.Add(new ProductoNoPerecedero
            {
                Nombre = "Pimienta en granos",
                Precio = 130.0,
                Tipo = "No Perecedero",
                Categoria = "Condimento"
            });


            // Mostramos los resultados recorriendo la lista de productos
            foreach (Producto producto  in productos)
            {
                Console.WriteLine(producto.mostrarDatos());
                Console.WriteLine("Precio: $" + producto.CalcularPrecioTotal(2));
                Console.WriteLine("-------------------------------");
            }
        }
    }
}
