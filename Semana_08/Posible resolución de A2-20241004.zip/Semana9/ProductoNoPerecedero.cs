﻿namespace Semana9
{
    class ProductoNoPerecedero : Producto
    {
        public string Categoria{ get; set; }

        public override string mostrarDatos()
        {
            string texto;
            texto = base.mostrarDatos();
            texto = texto + "\nCategoria: " + Categoria;
            return texto;
        }
    }
}
