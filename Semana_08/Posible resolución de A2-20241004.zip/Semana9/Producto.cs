﻿namespace Semana9
{
    abstract class Producto
    {
        public string Nombre { get; set; }
        public double Precio { get; set; }
        public string Tipo { get; set; }

        public virtual double CalcularPrecioTotal(int cantidad)
        {
            return Precio * cantidad;
        }

        public virtual string mostrarDatos()
        {
            string texto;
            texto = "Tipo: " + Tipo + "\nNombre: " + Nombre + "\nPrecio: " + Precio ;
            return texto;
        }
    }

}
