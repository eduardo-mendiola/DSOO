﻿namespace Semana9
{
    class ProductoPerecedero : Producto
    {
        public int DiasACaducar { get; set; }

        public override double CalcularPrecioTotal(int cantidad)
        {
            // Reducimos el precio en función de los días a caducar
            
            const int DIAS_A_CADUCAR_MAXIMOS = 10;
            const double PORCENTAJE_MAXIMOS_DIAS = 0.9;// 10% de descuento si faltan 10 o menos días para caducar
            const int DIAS_A_CADUCAR_MEDIOS = 5;
            const double PORCENTAJE_MEDIOS_DIAS = 0.7;// 30% de descuento si faltan 5 o menos días para caducar
            const int DIAS_A_CADUCAR_MINIMOS = 3;
            const double PORCENTAJE_MINIMOS_DIAS = 0.5;// 50% de descuento si faltan 3 o menos días para caducar

            double precioDescuento = base.CalcularPrecioTotal(cantidad);
            if (DiasACaducar <= DIAS_A_CADUCAR_MINIMOS)
                precioDescuento *= PORCENTAJE_MINIMOS_DIAS; 
            else if (DiasACaducar <= DIAS_A_CADUCAR_MEDIOS)
                precioDescuento *= PORCENTAJE_MEDIOS_DIAS; 
            else if (DiasACaducar <= DIAS_A_CADUCAR_MAXIMOS)
                precioDescuento *= PORCENTAJE_MAXIMOS_DIAS; 
            return precioDescuento;
        }

        public override string mostrarDatos()
        {
            string texto;
            texto = base.mostrarDatos();
            texto = texto + "\nDias a caducar: " + DiasACaducar;
            return texto;
        }
    }
}
